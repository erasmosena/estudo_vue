# 2.6 Locking Images to a Fixed Aspect Ratio

This lesson is built as a simple [Vue CLI](https://cli.vuejs.org/) app to better represent how a real-world project might be set up.

To get started, `cd` into this subfolder and run `npm install` to install the dependencies.

Use `npm run serve` to start the development server, or `npm run build` to compile the production assets to the `dist` folder.
