# 1.5 Composing Utilities with `@apply`

To get started, `cd` into this subfolder and run `npm install` to install the dependencies.

Use `npm run build` to generate the compiled CSS, and a tool like [live-server](https://www.npmjs.com/package/live-server) to preview the site in the browser.
